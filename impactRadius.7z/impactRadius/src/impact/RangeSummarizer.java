/*
Author: Sive Mbiza */
package impact;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RangeSummarizer implements NumberRangeSummarizer{
    /*
    Description: This method takes a String, splits it by comma
                  ,parse it to an Integer and then create 
                  a collection of type Intefer.
    Input: String 
    Output: Collection of Integer(Collection<Integer>)*/
    @Override
    public Collection<Integer> collect(String input) {
        return Stream.of(input.split(",")) //Split string by comma
                .map(Integer::valueOf)      // convert String type to Integer type
                .collect(Collectors.toList());} // create a collection list
    /*
    Description: This method produce a comma delimited list of numbers,
                 grouping the numbers into a range when they are sequential.
    Input: Collection of Integer(Collection<Integer>) 
    Output: String of numbers in ranges.*/                               
    @Override
    public String summarizeCollection(Collection<Integer> input){
        int [] inputToArray = input.stream()
                      .mapToInt(Integer::intValue)
                      .toArray();                   // Convert Collection list to an array .
        String outPut = "";                         // out put string
        Arrays.sort(inputToArray);                  // Sort array assuming it is not sorted
        List<List<Integer>>listMain = new ArrayList<>();  //Create lists of sequential list 
        List<Integer> temp = new ArrayList<>();
        // Loop the array and insert sequentioal numbers list in a list
        
        for(int i = 0;i<inputToArray.length;i++){
            if((i+1<inputToArray.length)&&(inputToArray[i]+1 ==inputToArray[i+1])){
                temp.add(inputToArray[i]);}
            else                        {
                temp.add(inputToArray[i]);
                listMain.add(temp);
                temp = new ArrayList<>();}}
        
        /*Get the minimum and maximum numbers from partitioned
          list and insert them in the output string */
        for(int i = 0;i<listMain.size();i++){
            if(listMain.get(i).size()>1){
                outPut +=(listMain.get(i).stream()      //Get min and max numbers
                         .mapToInt(Integer::intValue)
                         .min()
                         .getAsInt())+"-"+(listMain.get(i).stream()
                         .mapToInt(Integer::intValue)
                         .max()
                         .getAsInt())+", ";}
            else{
                outPut += listMain.get(i).get(0)+", ";}}
        return outPut.substring(0, outPut.length()-2);} //out put strint out the 2 last character(which ae " ,"
}


package Test;
import impact.RangeSummarizer;
import  org.junit.*;

public class Testing {
    RangeSummarizer rS = new RangeSummarizer();
    @Test
    /*Test for the input provided by you( Impact Radius)
     ****Note the space bettween ranges e.g "1, 23-4" not 1,3-4*/
    public void rangeSummarizerTest()throws Exception {
        String expResults = "1, 3, 6-8, 12-15, 21-24, 31";
        String str = "1,3,6,7,8,12,13,14,15,21,22,23,24,31";
        Assert.assertEquals(expResults,rS.summarizeCollection(rS.collect(str)));
        Assert.assertTrue(expResults.equals(rS.summarizeCollection(rS.collect(str))));}

    @Test
    /*This is just random input to see if it works and test when using different assert
    ****Note the space bettween ranges e.g "1, 23-4" not 1,3-4*/
public void boolTest()throws Exception {
    String expResults = "1, 3, 6-8, 12-15, 21-24, 31";
    String str = "1,3,6,7,8,12,13,14,15,21,22,23,24,31";
    Assert.assertTrue("13-14, 76-77, 88-89, 199-200".equals(rS.summarizeCollection(rS.collect("14,76,77,89,88,200,199,13"))));}

@Test
    /* This test case tests when negative number are included
    ****Note the space bettween ranges e.g "1, 23-4" not 1,3-4*/
    public void rangeSummarizerTest2()throws Exception {
        String expResults = "-5, -3-0, 5, 10-12, 67, 678";
        String str = "-1,5,67,-3,-5,-2,10,11,678,0,12";
        Assert.assertEquals(expResults,rS.summarizeCollection(rS.collect(str)));
        Assert.assertEquals(expResults,rS.summarizeCollection(rS.collect(str)));}
}
